﻿using Proyecto.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Proyecto.Mvc.Controllers
{
    public class BaseController: Controller
    {
        protected readonly IUnitOfWork _unit;

        public BaseController(IUnitOfWork unit)
        {
            this._unit = unit;
        }
        
    }
}
