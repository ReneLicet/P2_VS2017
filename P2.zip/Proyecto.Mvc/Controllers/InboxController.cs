﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Proyecto.Model;
using Proyecto.UnitOfWork;

namespace Proyecto.Mvc.Controllers
{
    public class InboxController : BaseController
    {
        public InboxController(IUnitOfWork unit) : base(unit)
        {
        }

        public ActionResult Index()
        {
            var emails = _unit.Emails.GetList();
            return View(emails);
        }
        [HttpPost]
        public ActionResult SearchMail(string q)
        {
            var emails = _unit.Emails.GetList();
            //return View("Index", emails.Where(e =>
            //                                    e.Message.ToUpper().Contains(q.ToUpper())
            //                                    || e.Subject.ToUpper().Contains(q.ToUpper()))
            //                                  );
            return RedirectToAction("Index", emails.Where(e =>
                                                 e.Message.ToUpper().Contains(q.ToUpper())
                                                 || e.Subject.ToUpper().Contains(q.ToUpper())));
        }

        public PartialViewResult CreateMail()
        {
            return PartialView("_CreateMail", new Email());
        }

        [HttpPost]
        public ActionResult CreateMail([Bind(Include = "Subject,Message,Receiver")]Email model)
        {
            if (!ModelState.IsValid) return View(model);
            model.Created = DateTime.Now;
            model.Sender = "system@enron.com";
            _unit.Emails.Insert(model);
            return RedirectToAction("Index");
        }

        public PartialViewResult ViewMail(int Id)
        {
            var email = _unit.Emails.GetById(Id);
            return PartialView("_ViewMail", email);
        }
    }
}
