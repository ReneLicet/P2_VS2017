﻿(function (mail) {
    mail.success = successReload;
    //customer.pages = 1;
    //customer.rowSize = 25;
    init();
    return mail;
    function successReload(option) {
        jimail.closeModal(option);
    }
    //function init() {
    //    $.get(
    //        "/Customer/Count/" + customer.rowSize,
    //        function (data) {
    //            customer.pages = data;
    //            $(".pagination")
    //                .bootpag({
    //                    total: customer.pages,
    //                    page: 1,
    //                    maxVisible: 5,
    //                    leaps: true,
    //                    firstLastUse: true,
    //                    first: "|<",
    //                    last: ">|",
    //                    wrapClass: "pagination",
    //                    activeClass: "active",
    //                    disabledClass: "disabled",
    //                    nextClass: "next",
    //                    prevClass: "prev",
    //                    lastClass: "last",
    //                    firstClass: "first",
    //                })
    //                .on("page", function (event, num) {
    //                    getCustomer(num);
    //                });
    //            getCustomer(1);
    //        });
    //}
    //function getCustomer(num) {
    //    var url = "/Customer/List/" + num + "/" + customer.rowSize;
    //    $.get(url, function (data) {
    //        $(".content").html(data);
    //    });
    //}
    function init() {
        var url = "/Inbox/Index/";
        $.get(url, function (data) {
            $(".content").html(data);
        });
    }
}
)(window.customer = window.customer || {});