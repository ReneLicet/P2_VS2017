﻿(function (jimail) {
    jimail.getModal = getModalContent;
    jimail.closeModal = closeModal;
    jimail.success = successReload;
    return jimail;
    function getModalContent(url) {
        $.get(url, function (data) {
            $('.modal-body').html(data);
        })
    }
    function closeModal() {
        $("button[data-dismiss='modal']").click();
        $('.modal-body').html("");
    }
    function successReload() {
        jimail.closeModal();
    }
}
)(window.jimail = window.jimail || {});