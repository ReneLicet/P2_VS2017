﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Repositories
{
    public interface IRepository<T> where T: class
    {
        IEnumerable<T> GetList();
        T GetById(int id);
        int Insert(T Entity);
        bool Update(T Entity);
        bool Delete(T Entity);

    }
}
