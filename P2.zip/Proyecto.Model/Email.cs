﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Model
{
    public class Email
    {
     
        public int Id { get; set; }
        [Required]

        public string Subject { get; set; }
        [Required]
        [DataType(DataType.MultilineText)]
        public string Message { get; set; }
        public string Sender { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        [Display(Name ="To")]
        public string Receiver { get; set; }
        public DateTime Created { get; set; }

    }
}
