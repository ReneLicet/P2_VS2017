﻿using Proyecto.Model;
using Proyecto.Repositories.Jimail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Repositories.Dapper.Jimail
{
    public class EmailRepository : Repository<Email>, IEmailRepository
    {
        public EmailRepository(string connectionString) : base(connectionString)
        {
        }
    }
}
