﻿using Proyecto.Repositories.Dapper.Jimail;
using Proyecto.Repositories.Jimail;
using Proyecto.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto.Repositories.Dapper.Cineo
{
    public class JimailUnitOfWork : IUnitOfWork
    {
        public JimailUnitOfWork(string connectionString)
        {
            Emails = new EmailRepository(connectionString);
        }

        public IEmailRepository Emails { get; private set; }
    }
}
